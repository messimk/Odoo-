# -*- coding: utf-8 -*-
from odoo import fields, models, api
import logging

_logger = logging.getLogger(__name__)

class PosSession(models.Model):
    _inherit = 'pos.session'
    
    def _loader_params_pos_config(self):
        result = super()._loader_params_pos_config()
        result['search_params']['fields'].extend([
            'enable_multi_warehouse',
            'warehouse_ids',
            'stock_type',
            'allow_negative_selling',
            'set_picking_to_ready'
        ])
        return result
    
    def _loader_params_product_product(self):
        result = super()._loader_params_product_product()
        # Add type field for product type detection
        if 'type' not in result.get('search_params', {}).get('fields', []):
            result['search_params']['fields'].append('type')
        return result