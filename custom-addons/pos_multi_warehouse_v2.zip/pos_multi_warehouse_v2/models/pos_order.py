# -*- coding: utf-8 -*-
from odoo import fields, models, api

class PosOrder(models.Model):
    _inherit = 'pos.order'
    
    # Add warehouse tracking if needed
    pass

class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'
    
    warehouse_id = fields.Many2one('stock.warehouse', string='Source Warehouse')
    location_id = fields.Many2one('stock.location', string='Source Location')