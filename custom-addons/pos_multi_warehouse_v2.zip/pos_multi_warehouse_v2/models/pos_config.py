# -*- coding: utf-8 -*-
from odoo import fields, models

class PosConfig(models.Model):
    _inherit = 'pos.config'
    
    # Multi-warehouse configuration fields
    enable_multi_warehouse = fields.Boolean(
        string='Enable Multi Warehouse',
        help='Allow selection of products from multiple warehouses in POS'
    )
    
    warehouse_ids = fields.Many2many(
        'stock.warehouse',
        string='Available Warehouses',
        help='Select warehouses available for this POS'
    )
    
    stock_type = fields.Selection([
        ('available_qty', 'Available Quantity'),
        ('unreserved_qty', 'Available Quantity Unreserved')
    ], string='Stock Type', default='available_qty',
       help='Type of stock to display in POS')
    
    allow_negative_selling = fields.Boolean(
        string='Allow Negative Selling',
        help='Allow selling products even when stock is negative'
    )
    
    set_picking_to_ready = fields.Boolean(
        string='Set Picking to Ready State',
        help='If checked, picking will be set to ready state instead of done'
    )