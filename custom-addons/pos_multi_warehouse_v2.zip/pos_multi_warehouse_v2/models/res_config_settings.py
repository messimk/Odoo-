# -*- coding: utf-8 -*-
from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    pos_enable_multi_warehouse = fields.Boolean(
        related='pos_config_id.enable_multi_warehouse',
        readonly=False
    )
    
    pos_warehouse_ids = fields.Many2many(
        related='pos_config_id.warehouse_ids',
        readonly=False
    )
    
    pos_stock_type = fields.Selection(
        related='pos_config_id.stock_type',
        readonly=False
    )
    
    pos_allow_negative_selling = fields.Boolean(
        related='pos_config_id.allow_negative_selling',
        readonly=False
    )
    
    pos_set_picking_to_ready = fields.Boolean(
        related='pos_config_id.set_picking_to_ready',
        readonly=False
    )