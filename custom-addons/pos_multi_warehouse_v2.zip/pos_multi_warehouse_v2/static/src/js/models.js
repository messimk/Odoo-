/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { Order, Orderline } from "@point_of_sale/app/store/models";

// Patch Order to handle multi-warehouse
patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
        this.multiWarehouseMode = false;
    },
    
    async addProductFromWarehouse(product, warehouseData) {
        // Add product with specific warehouse info
        for (const warehouse of warehouseData) {
            if (warehouse.quantity > 0) {
                await this.add_product(product, {
                    quantity: warehouse.quantity,
                    warehouse_id: warehouse.warehouse_id,
                    location_id: warehouse.location_id,
                    merge: false
                });
            }
        }
    }
});

// Patch Orderline to store warehouse info
patch(Orderline.prototype, {
    setup() {
        super.setup(...arguments);
        this.warehouse_id = null;
        this.location_id = null;
    },
    
    setWarehouseInfo(warehouseId, locationId) {
        this.warehouse_id = warehouseId;
        this.location_id = locationId;
    },
    
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.warehouse_id = this.warehouse_id;
        json.location_id = this.location_id;
        return json;
    }
});