/** @odoo-module */

console.log("==== POS MULTI WAREHOUSE V2 MODULE LOADED ====");
console.log("This module is active and JavaScript is loading");

import { patch } from "@web/core/utils/patch";
import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";

// Simple test patch
patch(ProductCard.prototype, {
    setup() {
        super.setup(...arguments);
        console.log("ProductCard setup - Multi Warehouse Module Active");
    }
});

// Add a simple test on window load
if (typeof window !== 'undefined') {
    window.addEventListener('load', () => {
        console.log("Window loaded - POS Multi Warehouse V2 is active");
    });
}