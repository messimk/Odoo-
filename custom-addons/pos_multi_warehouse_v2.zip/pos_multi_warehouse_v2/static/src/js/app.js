/** @odoo-module */

import { registry } from "@web/core/registry";
import { WarehousePopup } from "./WarehousePopup";

// Register the warehouse popup
const posPopups = registry.category("pos_popups");
posPopups.add("WarehousePopup", WarehousePopup);