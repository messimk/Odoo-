/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";

// Patch PosStore to load warehouse data via RPC
patch(PosStore.prototype, {
    async load_server_data() {
        await super.load_server_data(...arguments);
        
        console.log('POS Config after load:', this.config);
        console.log('Enable multi warehouse (before manual load):', this.config?.enable_multi_warehouse);
        
        // Wait a bit for config_loader to update the config
        await new Promise(resolve => setTimeout(resolve, 100));
        
        console.log('Enable multi warehouse (after wait):', this.config?.enable_multi_warehouse);
        
        // Load if multi-warehouse is enabled
        if (this.config && this.config.enable_multi_warehouse) {
            await this.loadWarehouseData();
        }
    },
    
    async loadWarehouseData() {
        try {
            // Load warehouses
            const warehouses = await this.env.services.orm.searchRead(
                'stock.warehouse',
                [['id', 'in', this.config.warehouse_ids || []]],
                ['id', 'name', 'code', 'lot_stock_id']
            );
            this.warehouses = warehouses;
            
            // Load warehouse locations
            const locationIds = warehouses
                .filter(w => w.lot_stock_id)
                .map(w => w.lot_stock_id[0]);
            
            if (locationIds.length > 0) {
                // Load stock quants for these locations
                const quants = await this.env.services.orm.searchRead(
                    'stock.quant',
                    [
                        ['location_id', 'in', locationIds],
                        ['quantity', '>', 0]
                    ],
                    ['id', 'product_id', 'location_id', 'quantity', 'reserved_quantity']
                );
                
                this.quants = quants;
                
                // Build quant index
                this.quantsByProductLocation = {};
                for (const quant of quants) {
                    const productId = quant.product_id[0];
                    const locationId = quant.location_id[0];
                    
                    if (!this.quantsByProductLocation[productId]) {
                        this.quantsByProductLocation[productId] = {};
                    }
                    
                    this.quantsByProductLocation[productId][locationId] = {
                        quantity: quant.quantity,
                        reserved: quant.reserved_quantity,
                        available: quant.quantity - quant.reserved_quantity
                    };
                }
            }
            
            console.log('Warehouse data loaded:', {
                warehouses: this.warehouses.length,
                quants: this.quants?.length || 0
            });
            
        } catch (error) {
            console.error('Error loading warehouse data:', error);
            this.warehouses = [];
            this.quants = [];
            this.quantsByProductLocation = {};
        }
    },
    
    getProductWarehouseStock(productId) {
        const warehouseStock = [];
        
        if (!this.config.enable_multi_warehouse) {
            return warehouseStock;
        }
        
        const warehouses = this.config.warehouse_ids || [];
        const productQuants = this.quantsByProductLocation?.[productId] || {};
        
        for (const warehouseId of warehouses) {
            const warehouse = this.warehouses?.find(w => w.id === warehouseId);
            if (warehouse && warehouse.lot_stock_id) {
                const locationId = warehouse.lot_stock_id[0];
                const quant = productQuants[locationId] || { quantity: 0, available: 0 };
                
                const stockValue = this.config.stock_type === 'unreserved_qty' 
                    ? quant.available 
                    : quant.quantity;
                
                warehouseStock.push({
                    warehouse_id: warehouse.id,
                    warehouse_name: warehouse.name,
                    location_id: locationId,
                    quantity: stockValue || 0
                });
            }
        }
        
        // Add all configured warehouses even if no stock
        for (const warehouseId of warehouses) {
            const warehouse = this.warehouses?.find(w => w.id === warehouseId);
            if (warehouse) {
                const existing = warehouseStock.find(ws => ws.warehouse_id === warehouse.id);
                if (!existing) {
                    warehouseStock.push({
                        warehouse_id: warehouse.id,
                        warehouse_name: warehouse.name,
                        location_id: warehouse.lot_stock_id?.[0] || null,
                        quantity: 0
                    });
                }
            }
        }
        
        return warehouseStock;
    }
});