/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";

// Patch PosStore to load our custom config fields
patch(PosStore.prototype, {
    async _processData(loadedData) {
        await super._processData(...arguments);
        
        console.log('Config ID:', this.config?.id);
        console.log('Initial config enable_multi_warehouse:', this.config?.enable_multi_warehouse);
        
        // Always fetch the multi-warehouse config fields to ensure they're loaded
        if (this.config) {
            try {
                const configData = await this.env.services.orm.read(
                    'pos.config',
                    [this.config.id],
                    ['enable_multi_warehouse', 'warehouse_ids', 'stock_type', 'allow_negative_selling', 'set_picking_to_ready']
                );
                
                if (configData && configData.length > 0) {
                    Object.assign(this.config, configData[0]);
                    console.log('Loaded multi-warehouse config:', {
                        enable_multi_warehouse: this.config.enable_multi_warehouse,
                        warehouse_ids: this.config.warehouse_ids,
                        stock_type: this.config.stock_type
                    });
                }
            } catch (error) {
                console.error('Error loading multi-warehouse config:', error);
            }
        }
        
        // Load product types if not loaded
        if (this.db && this.db.product_by_id) {
            const productIds = Object.keys(this.db.product_by_id);
            if (productIds.length > 0) {
                const firstProduct = this.db.product_by_id[productIds[0]];
                if (!('type' in firstProduct)) {
                    try {
                        const products = await this.env.services.orm.searchRead(
                            'product.product',
                            [['id', 'in', productIds.map(id => parseInt(id))]],
                            ['id', 'type'],
                            { limit: 1000 }
                        );
                        
                        for (const prod of products) {
                            if (this.db.product_by_id[prod.id]) {
                                this.db.product_by_id[prod.id].type = prod.type;
                            }
                        }
                        console.log('Loaded product types for', products.length, 'products');
                    } catch (error) {
                        console.error('Error loading product types:', error);
                    }
                }
            }
        }
    }
});