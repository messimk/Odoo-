/** @odoo-module */

import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";
import { _t } from "@web/core/l10n/translation";
import { useState, useRef, onMounted } from "@odoo/owl";

export class WarehousePopup extends AbstractAwaitablePopup {
    static template = "pos_multi_warehouse_v2.WarehousePopup";
    static defaultProps = {
        title: _t("Select Warehouse Quantities"),
        confirmText: _t("Add to Cart"),
        cancelText: _t("Cancel"),
    };

    setup() {
        super.setup();
        this.state = useState({
            warehouseQuantities: {},
            total: 0
        });
        
        // Initialize warehouse quantities
        for (const warehouse of this.props.warehouses) {
            this.state.warehouseQuantities[warehouse.warehouse_id] = 0;
        }
        
        this.inputRefs = {};
        for (const warehouse of this.props.warehouses) {
            this.inputRefs[warehouse.warehouse_id] = useRef(`input-${warehouse.warehouse_id}`);
        }
        
        onMounted(() => {
            // Focus first input
            const firstInput = Object.values(this.inputRefs)[0];
            if (firstInput && firstInput.el) {
                firstInput.el.focus();
            }
        });
    }
    
    updateQuantity(warehouseId, value) {
        const warehouse = this.props.warehouses.find(w => w.warehouse_id === warehouseId);
        const maxQty = warehouse ? warehouse.quantity : 0;
        const qty = parseFloat(value) || 0;
        
        // Validate quantity
        if (!this.env.services.pos.config.allow_negative_selling && qty > maxQty) {
            this.env.services.notification.add(
                _t("Quantity exceeds available stock"),
                { type: 'warning' }
            );
            this.state.warehouseQuantities[warehouseId] = maxQty;
        } else if (qty < 0) {
            this.state.warehouseQuantities[warehouseId] = 0;
        } else {
            this.state.warehouseQuantities[warehouseId] = qty;
        }
        
        // Update total
        this.updateTotal();
    }
    
    updateTotal() {
        this.state.total = Object.values(this.state.warehouseQuantities)
            .reduce((sum, qty) => sum + qty, 0);
    }
    
    async confirm() {
        const selectedWarehouses = [];
        
        for (const [warehouseId, quantity] of Object.entries(this.state.warehouseQuantities)) {
            if (quantity > 0) {
                const warehouse = this.props.warehouses.find(
                    w => w.warehouse_id === parseInt(warehouseId)
                );
                if (warehouse) {
                    selectedWarehouses.push({
                        ...warehouse,
                        quantity: quantity
                    });
                }
            }
        }
        
        if (selectedWarehouses.length === 0) {
            this.env.services.notification.add(
                _t("Please select at least one warehouse with quantity"),
                { type: 'warning' }
            );
            return;
        }
        
        await super.confirm();
        return selectedWarehouses;
    }
    
    getPayload() {
        const selectedWarehouses = [];
        
        for (const [warehouseId, quantity] of Object.entries(this.state.warehouseQuantities)) {
            if (quantity > 0) {
                const warehouse = this.props.warehouses.find(
                    w => w.warehouse_id === parseInt(warehouseId)
                );
                if (warehouse) {
                    selectedWarehouses.push({
                        ...warehouse,
                        quantity: quantity
                    });
                }
            }
        }
        
        return selectedWarehouses;
    }
}