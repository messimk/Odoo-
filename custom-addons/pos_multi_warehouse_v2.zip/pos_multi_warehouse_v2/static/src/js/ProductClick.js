/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";
import { _t } from "@web/core/l10n/translation";

patch(ProductCard.prototype, {
    async onProductClick() {
        console.log('ProductClick: onProductClick triggered');
        const product = this.props.product;
        const pos = this.env.services.pos;
        
        console.log('ProductClick: Config:', {
            enable_multi_warehouse: pos.config.enable_multi_warehouse,
            product_type: product.type,
            product_name: product.display_name
        });
        
        // Check if multi-warehouse is enabled and product is storable
        if (pos.config.enable_multi_warehouse && product.type === 'product') {
            console.log('ProductClick: Multi-warehouse enabled for storable product');
            // Get warehouse stock for this product
            const warehouseStock = pos.getProductWarehouseStock(product.id);
            console.log('ProductClick: Warehouse stock:', warehouseStock);
            
            if (warehouseStock.length > 0) {
                console.log('ProductClick: Showing warehouse popup');
                // Show warehouse selection popup
                const { confirmed, payload } = await this.env.services.popup.add('WarehousePopup', {
                    title: `${product.display_name} - Select Warehouse`,
                    warehouses: warehouseStock,
                    product: product
                });
                
                if (confirmed && payload) {
                    // Add product with selected warehouse quantities
                    const order = pos.get_order();
                    await order.addProductFromWarehouse(product, payload);
                }
            } else {
                // No stock available
                if (!pos.config.allow_negative_selling) {
                    this.env.services.notification.add(
                        _t("No stock available in configured warehouses"),
                        { type: 'warning' }
                    );
                } else {
                    // Allow negative selling
                    await super.onProductClick();
                }
            }
        } else {
            // Normal product click for non-storable products
            await super.onProductClick();
        }
    }
});