/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { _t } from "@web/core/l10n/translation";
import { WarehousePopup } from "./WarehousePopup";

patch(PosStore.prototype, {
    async addProductToCurrentOrder(product, options = {}) {
        console.log('addProductToCurrentOrder called for:', product.display_name);
        console.log('Multi-warehouse enabled:', this.config.enable_multi_warehouse);
        console.log('Product object:', product);
        console.log('Product type:', product.type);
        
        // Check if multi-warehouse is enabled and product is storable
        if (this.config.enable_multi_warehouse && product.type === 'product') {
            console.log('Multi-warehouse mode - checking stock...');
            
            // Get warehouse stock for this product
            const warehouseStock = this.getProductWarehouseStock(product.id);
            console.log('Warehouse stock:', warehouseStock);
            
            if (warehouseStock && warehouseStock.length > 0) {
                console.log('Showing warehouse popup...');
                
                // Show warehouse selection popup
                try {
                    const { confirmed, payload } = await this.env.services.popup.add(WarehousePopup, {
                        title: `${product.display_name} - Select Warehouse`,
                        warehouses: warehouseStock,
                        product: product
                    });
                    
                    if (confirmed && payload) {
                        console.log('Adding products from warehouses:', payload);
                        // Add product with selected warehouse quantities
                        const order = this.get_order();
                        for (const warehouse of payload) {
                            if (warehouse.quantity > 0) {
                                await super.addProductToCurrentOrder(product, {
                                    ...options,
                                    quantity: warehouse.quantity,
                                    warehouse_id: warehouse.warehouse_id,
                                    location_id: warehouse.location_id,
                                    merge: false
                                });
                            }
                        }
                    }
                } catch (error) {
                    console.error('Error showing warehouse popup:', error);
                }
            } else {
                // No stock available
                console.log('No stock available');
                if (!this.config.allow_negative_selling) {
                    this.env.services.notification.add(
                        _t("No stock available in configured warehouses"),
                        { type: 'warning' }
                    );
                } else {
                    // Allow negative selling
                    await super.addProductToCurrentOrder(product, options);
                }
            }
        } else {
            // Normal product click for non-storable products or when multi-warehouse is disabled
            console.log('Normal mode - adding product directly');
            await super.addProductToCurrentOrder(product, options);
        }
    }
});