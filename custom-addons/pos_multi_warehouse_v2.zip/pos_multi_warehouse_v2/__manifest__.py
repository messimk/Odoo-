# -*- coding: utf-8 -*-
{
    'name': 'POS Multi Warehouse V2',
    'version': '17.0.1.0.0',
    'category': 'Point of Sale',
    'summary': 'Manage multiple warehouses in POS with stock selection popup',
    'description': """
        POS Multi Warehouse Module
        ===========================
        Features:
        - Manage multiple warehouses in POS session
        - Add products from multiple warehouses
        - Show available stock per warehouse
        - Popup for warehouse selection when clicking products
        - Support for negative selling option
        - Stock type configuration (Available/Unreserved)
    """,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'depends': ['point_of_sale', 'stock'],
    'data': [
        'views/pos_config_views.xml',
        # Temporarily disabled: 'views/res_config_settings_views.xml',
    ],
    'assets': {
        'point_of_sale.assets_prod': [
            'pos_multi_warehouse_v2/static/src/js/test_loader.js',
            'pos_multi_warehouse_v2/static/src/js/config_loader.js',
            'pos_multi_warehouse_v2/static/src/js/warehouse_loader.js',
            'pos_multi_warehouse_v2/static/src/js/models.js',
            'pos_multi_warehouse_v2/static/src/js/WarehousePopup.js',
            'pos_multi_warehouse_v2/static/src/js/ProductClick_v2.js',
            'pos_multi_warehouse_v2/static/src/js/app.js',
            'pos_multi_warehouse_v2/static/src/xml/WarehousePopup.xml',
            'pos_multi_warehouse_v2/static/src/scss/warehouse_popup.scss',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}