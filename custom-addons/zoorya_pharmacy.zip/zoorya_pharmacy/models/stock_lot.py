from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import date

class StockLot(models.Model):
    _inherit = 'stock.lot'

    @api.constrains('expiration_date')
    def _check_expiration_date(self):
        for lot in self:
            if lot.expiration_date and lot.expiration_date.date() < date.today():
                raise UserError(
                    f"Lot {lot.name} for product {lot.product_id.name} has expired on {lot.expiration_date.strftime('%d/%m/%Y')}. Cannot be used."
                )