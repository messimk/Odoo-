from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import date

class ProductProduct(models.Model):
    _inherit = 'product.product'

    def _check_expiry(self, lot_id):
        lot = self.env['stock.lot'].browse(lot_id)
        if lot.expiration_date and lot.expiration_date.date() < date.today():
            raise UserError(
                f"Product {self.name} in Lot {lot.name} expired on {lot.expiration_date.strftime('%d/%m/%Y')}. Please select another lot."
            )