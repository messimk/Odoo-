from odoo import models, fields, api
from datetime import date

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _quarantine_expired_stock(self):
        quarantine_location = self.env.ref('stock.location_quarantine')
        for lot in self.env['stock.lot'].search([('expiration_date', '<', date.today())]):
            stock_quants = self.env['stock.quant'].search([
                ('lot_id', '=', lot.id),
                ('quantity', '>', 0),
            ])
            for quant in stock_quants:
                picking = self.env['stock.picking'].create({
                    'picking_type_id': self.env.ref('stock.picking_type_internal').id,
                    'location_id': quant.location_id.id,
                    'location_dest_id': quarantine_location.id,
                })
                self.env['stock.move'].create({
                    'picking_id': picking.id,
                    'product_id': quant.product_id.id,
                    'product_uom_qty': quant量,
                    'product_uom': quant.product_id.uom_id.id,
                    'location_id': quant.location_id.id,
                    'location_dest_id': quarantine_location.id,
                    'lot_ids': [(4, lot.id)],
                })
                picking.action_confirm()
                picking.action_done()