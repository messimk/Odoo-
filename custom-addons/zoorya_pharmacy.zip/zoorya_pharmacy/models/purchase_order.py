from odoo import models, api
from odoo.exceptions import UserError
from datetime import date

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def button_confirm(self):
        for line in self.order_line:
            for lot in line.move_ids.mapped('lot_ids'):
                if lot.expiration_date and lot.expiration_date.date() < date.today():
                    raise UserError(
                        f"Product {line.product_id.name} in Lot {lot.name} has expired on {lot.expiration_date.strftime('%d/%m/%Y')}. Receipt blocked."
                    )
        return super(PurchaseOrder, self).button_confirm()