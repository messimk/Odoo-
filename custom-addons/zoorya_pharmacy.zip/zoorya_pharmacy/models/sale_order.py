from odoo import models, api
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        # First, run Odoo's standard action_confirm logic
        res = super(SaleOrder, self).action_confirm()

        # Then apply your custom logic
        for order in self:
            for line in order.order_line:
                for lot in line.move_ids.mapped('lot_ids'):
                    line.product_id._check_expiry(lot.id)

        return res