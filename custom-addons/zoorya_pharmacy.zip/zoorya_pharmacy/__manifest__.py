{
    'name': 'Zoorya Pharmacy Enhancements',
    'version': '1.0',
    'category': 'Pharmacy',
    'summary': 'Pharmacy management enhancements for Zoorya in Odoo 17',
    'depends': ['base', 'point_of_sale', 'sale_management', 'purchase', 'stock'],
    'data': [
        'data/scheduled_actions.xml',
        'views/pos_report_views.xml',
        # 'views/invoice_report_views.xml',
        # 'views/grn_report_views.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            # 'zoorya_pharmacy/static/src/js/pos_lot_selection.js',
            'zoorya_pharmacy/static/src/xml/pos_templates.xml',
            'zoorya_pharmacy/static/src/xml/pos_receipt.xml',
        ],
    },
    'installable': True,
    'auto_install': False,
}