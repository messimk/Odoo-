// odoo.define('zoorya_pharmacy.PosLotSelection', function (require) {
//     'use strict';

//     const PosComponent = require('point_of_sale.PosComponent');
//     const Registries = require('point_of_sale.Registries');
//     const { useState } = owl;

//     class LotSelectionScreen extends PosComponent {
//         setup() {
//             super.setup();
//             this.state = useState({ selectedLot: null });
//         }

//         async getLots(product) {
//             const lots = await this.rpc({
//                 model: 'stock.lot',
//                 method: 'search_read',
//                 args: [[['product_id', '=', product.id], ['expiration_date', '>=', new Date().toISOString().split('T')[0]]]],
//                 fields: ['name', 'expiration_date'],
//                 order: [{ name: 'expiration_date', asc: true }],
//             });
//             return lots;
//         }

//         async onSelectLot(lot) {
//             this.state.selectedLot = lot;
//             this.env.pos.get_order().get_selected_orderline().set_lot(lot);
//             this.close();
//         }
//     }

//     LotSelectionScreen.template = 'zoorya_pharmacy.LotSelectionScreen';
//     Registries.Component.add(LotSelectionScreen);

//     return LotSelectionScreen;
// });