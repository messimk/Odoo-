# pos_zmall_first
#Products always flow from Odoo to Zmall; there should be  no reverse synchronization.

