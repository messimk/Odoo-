# -*- coding: utf-8 -*-
from . import pos_category
from . import pos_config
from . import res_config_settings
from . import product
from . import pos_session
from . import orders
