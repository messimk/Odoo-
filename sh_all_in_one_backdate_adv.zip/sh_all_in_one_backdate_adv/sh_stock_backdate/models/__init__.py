from . import stock_config_settings
from . import stock_move
from . import stock_picking
# from . import stock_inventory  # Removed - stock.inventory doesn't exist in Odoo 17
from . import stock_scrap
from . import stock_move_line